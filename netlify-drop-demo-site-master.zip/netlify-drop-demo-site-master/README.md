# Thanos JS (demo site)

Silly demo site to be used for [Netlify Drop](https://app.netlify.com/drop).

Preview demo site [right here](https://www.thanosjs.org).

Thanks to [Rasmus Andersson](https://twitter.com/rsms) for creating [Inter UI font](https://rsms.me/inter/).
